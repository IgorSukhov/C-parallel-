#include "task3.h"

#include <iostream>
#include <chrono>
#include <thread>

using namespace std;

void Task3()
{
    char ch = 'A';
    for(int i=0;i<26;i++)
    {
        cout << ch++;
        this_thread::sleep_for(chrono::milliseconds(10+i*10));
    }
    cout << endl;
}
