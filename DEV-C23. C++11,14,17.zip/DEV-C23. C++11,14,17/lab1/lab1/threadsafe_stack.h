#ifndef THREADSAFE_STACK_H
#define THREADSAFE_STACK_H

#include <vector>
#include <mutex>
#include <memory>

using namespace std;

class threadsafe_stack
{
    vector<int> v;
    mutex m;

    //lock_guard<mutex> lg(m);
public:
    threadsafe_stack();
    threadsafe_stack(const threadsafe_stack &other);
    threadsafe_stack(threadsafe_stack &&other);
    threadsafe_stack &operator= (const threadsafe_stack &other);
    threadsafe_stack &operator= (threadsafe_stack &&other);

    vector<int> &getVector() { return v; }
    const mutex *getMutex() const { return &m; }

    void push(int val);
    void pop(int& val);
    std::shared_ptr<int> pop();
private:

};

#endif // THREADSAFE_STACK_H
