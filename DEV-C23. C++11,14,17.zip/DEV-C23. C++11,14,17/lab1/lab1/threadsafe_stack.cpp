#include "threadsafe_stack.h"
#include <iostream>

threadsafe_stack::threadsafe_stack()
{

}

threadsafe_stack::threadsafe_stack(const threadsafe_stack &other)
{

    std::lock_guard<std::mutex> lock(other.m);
    std::cout << "copy constr" << endl;
}

threadsafe_stack::threadsafe_stack(threadsafe_stack &&other)
{

    std::cout << "move constr" << endl;
}

threadsafe_stack &threadsafe_stack::operator=(const threadsafe_stack &other)
{
    std::cout << "equal copy" << endl;
}

threadsafe_stack &threadsafe_stack::operator=(threadsafe_stack &&other)
{
    std::cout << "equal move" << endl;
}

void threadsafe_stack::push(int val)
{
    std::lock_guard<std::mutex> lock(m);
    v.push_back(val);
}

void threadsafe_stack::pop(int &val)
{
    std::lock_guard<std::mutex> lock(m);
    if(v.empty()) throw;
    val = v.back();
    v.pop_back();
}

std::shared_ptr<int> threadsafe_stack::pop()
{
    std::lock_guard<std::mutex> lock(m);
    if(v.empty()) throw;
    static int val = v.back();
    std::shared_ptr<int> p(&val);
    return p;
}
