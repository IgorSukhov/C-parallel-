#include "task5.h"
#include "threadsafe_stack.h"

#include <thread>
using namespace std;

void f()
{
    std::chrono::seconds(1);
}

void foo1(threadsafe_stack st)
{

}

//threadsafe_stack foo2()
//{
//    return
//}

void Task5()
{
    threadsafe_stack st1;
    //thread th1();
    threadsafe_stack st2(st1);
    threadsafe_stack st3 = st1;
    st3 = st2;

    //foo1(st1);
    //st2 = foo2();
}
