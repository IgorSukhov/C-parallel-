#ifndef TASK5_H
#define TASK5_H


void Task5();

#endif // TASK5_H
