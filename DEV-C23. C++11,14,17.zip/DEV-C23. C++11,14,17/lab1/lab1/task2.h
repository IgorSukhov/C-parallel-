#ifndef TASK2_H
#define TASK2_H

void Task2();

#endif // TASK2_H
