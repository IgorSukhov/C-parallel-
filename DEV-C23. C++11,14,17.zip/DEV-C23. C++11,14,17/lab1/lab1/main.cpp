#include "task1.h"
#include "task2.h"
#include "task3.h"
#include "task4.h"
#include "task5.h"

int main()//int argc, char *argv[]
{

//    Task1();
//    Task2();
//    Task3();
    //Task4();


   Task5();



    return 0;
}


