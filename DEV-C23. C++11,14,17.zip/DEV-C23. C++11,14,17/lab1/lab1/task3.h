#ifndef TASK3_H
#define TASK3_H


void Task3();

#endif // TASK3_H
