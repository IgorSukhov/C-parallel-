#ifndef TASK1_H
#define TASK1_H

void Task1();

#endif // TASK1_H
