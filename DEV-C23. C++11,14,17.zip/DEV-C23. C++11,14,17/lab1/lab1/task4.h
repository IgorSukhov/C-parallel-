#ifndef TASK4_H
#define TASK4_H


void Task4();

#endif // TASK4_H
